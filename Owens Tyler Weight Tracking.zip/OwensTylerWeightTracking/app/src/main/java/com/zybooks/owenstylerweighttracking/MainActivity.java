package com.zybooks.owenstylerweighttracking;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ActionMenuView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private WeightRecordDatabase weightdb;
    private Button addButton;
    private Button removeButton;
    private Button editButton;
    private Button goalButton;
    private TextView list;
    private TextView goal;
    private Activity here;
    private double maxWeight;
    private ConstraintLayout mainLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        here = this;


        weightdb = new WeightRecordDatabase(this);
        list = (TextView) findViewById(R.id.itemList);
        addButton = (Button) findViewById(R.id.buttonAddWeight);
        removeButton = (Button) findViewById(R.id.buttonRemoveWeight);
        editButton = (Button) findViewById(R.id.buttonChangeWeight);
        goalButton = (Button) findViewById(R.id.buttonChangeGoal);
        goal = (TextView) findViewById(R.id.textViewGoalWeight);
        mainLayout = (ConstraintLayout) findViewById(R.id.mainLayout);

        addButton.setOnClickListener(this);
        removeButton.setOnClickListener(this);
        editButton.setOnClickListener(this);
        goalButton.setOnClickListener(this);

        weightdb.clean();

        displayWeights();

        checkSMSPermissions();


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.buttonAddWeight:
                addWeight();
                break;
            case R.id.buttonChangeWeight:
                changeWeight();
                break;
            case R.id.buttonRemoveWeight:
                removeWeight();
                break;
            case R.id.buttonChangeGoal:
                changeGoal();
                break;
        }

    }

    private void addWeight() {
        // inflate the layout of the popup window
        LayoutInflater inflater
                = (LayoutInflater)getBaseContext()
                .getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.add_weight,null);

        // create the popup window
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
        popupWindow.setTouchable(true);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window token
        popupWindow.showAtLocation(findViewById(R.id.mainLayout), Gravity.CENTER, 0, 0);

        Button okButton = (Button) popupView.findViewById(R.id.buttonPopUpAdd);
        okButton.setEnabled(true);

        EditText dateText = (EditText) popupView.findViewById(R.id.textDateAdd);
        EditText weightText = (EditText) popupView.findViewById(R.id.editTextWeightAdd) ;

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    Double newWeight = Double.parseDouble(weightText.getText().toString().trim());

                    underGoal(newWeight);
                    WeightRecord weight = new WeightRecord();
                    weight.setDate(dateText.getText().toString().trim());
                    weight.setWeight(weightText.getText().toString().trim());

                    weightdb.addWeight( weight );

                    displayWeights();
                } catch (Exception e) {

                    Log.e("add: ", e.toString() + weightText.getText().toString());


                    Snackbar.make(mainLayout, getString(R.string.invalid_weight), Snackbar.LENGTH_LONG).show();
                }

                popupWindow.dismiss();

            }
        });
        // dismiss the popup window when touched
        popupView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                popupWindow.dismiss();
                return true;
            }
        });

    }


    private void changeWeight() {
        // inflate the layout of the popup window
        LayoutInflater inflater
                = (LayoutInflater)getBaseContext()
                .getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.edit_weight,null);

        // create the popup window
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
        popupWindow.setTouchable(true);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window token
        popupWindow.showAtLocation(findViewById(R.id.mainLayout), Gravity.CENTER, 0, 0);

        Button okButton = (Button) popupView.findViewById(R.id.buttonPopUpEdit);
        okButton.setEnabled(true);

        EditText idText = (EditText) popupView.findViewById(R.id.textEditID) ;
        idText.setText("");

        EditText dateText = (EditText) popupView.findViewById(R.id.textDateEdit);
        dateText.setText("");
        EditText weightText = (EditText) popupView.findViewById(R.id.editTextWeightEdit) ;
        weightText.setText("");

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Double newWeight =Double.parseDouble(weightText.getText().toString().trim());

                    underGoal(newWeight);
                    WeightRecord weight = new WeightRecord();
                    weight.setId(Integer.parseInt(idText.getText().toString().trim()));
                    weight.setDate(dateText.getText().toString().trim());
                    weight.setWeight(newWeight.toString());

                    weightdb.updateWeight( weight );

                    displayWeights();
                } catch (Exception e) {


                    Snackbar.make(mainLayout, getString(R.string.invalid_weight), Snackbar.LENGTH_LONG).show();
                }
                popupWindow.dismiss();
            }
        });
        // dismiss the popup window when touched
        popupView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                popupWindow.dismiss();
                return true;
            }
        });

    }



    private void removeWeight() {
        // inflate the layout of the popup window
        LayoutInflater inflater
                = (LayoutInflater)getBaseContext()
                .getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.remove_weight,null);

        // create the popup window
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
        popupWindow.setTouchable(true);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window token
        popupWindow.showAtLocation(findViewById(R.id.mainLayout), Gravity.CENTER, 0, 0);

        Button okButton = (Button) popupView.findViewById(R.id.buttonPopUpEdit);
        okButton.setEnabled(true);

        EditText idText = (EditText) popupView.findViewById(R.id.textEditID) ;
        idText.setText("");


        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //switch (v.getId()) {
                //case R.id.buttonPopUpAdd:\
                WeightRecord weight = new WeightRecord();
                weight.setId(Integer.parseInt(idText.getText().toString().trim()));

                weightdb.removeWeight(weight);

                displayWeights();
                popupWindow.dismiss();
                // break;
                //}
            }
        });
        // dismiss the popup window when touched
        popupView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                popupWindow.dismiss();
                return true;
            }
        });

    }

    private void changeGoal() {
        // inflate the layout of the popup window
        LayoutInflater inflater
                = (LayoutInflater)getBaseContext()
                .getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.change_goal,null);

        // create the popup window
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
        popupWindow.setTouchable(true);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window token
        popupWindow.showAtLocation(findViewById(R.id.mainLayout), Gravity.CENTER, 0, 0);

        Button okButton = (Button) popupView.findViewById(R.id.buttonPopUpEdit);
        okButton.setEnabled(true);

        EditText idText = (EditText) popupView.findViewById(R.id.textEditID) ;
        idText.setText("");


        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    Double newGoal = Double.parseDouble(idText.getText().toString().trim());


                    weightdb.setGoalWeight(newGoal);

                    displayWeights();
                } catch (Exception e) {


                    Snackbar.make(mainLayout, getString(R.string.invalid_weight), Snackbar.LENGTH_LONG).show();
                }
                popupWindow.dismiss();
            }
        });
        // dismiss the popup window when touched
        popupView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                popupWindow.dismiss();
                return true;
            }
        });

    }

    private void displayWeights() {
        StringBuffer itemText = new StringBuffer();
        List<WeightRecord> weights = weightdb.getAllWeights();
        for (int i = 0; i < weights.size(); i++) {
            itemText.append("ID. " + weights.get(i).getId() +"  Date: " + weights.get(i).getDate() + "  Weight: " + weights.get(i).getWeight() + "\n");
        }

        list.setText(itemText);
        if(weightdb.getGoalWeight() != null){
            goal.setText("Goal Weight: " + weightdb.getGoalWeight().toString().trim());
        }
    }


    private void checkSMSPermissions(){
        //System.out.println("checking sms permissions");
        Log.e("", "seeing if permission TLO");
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            //TODO ask for permission here with a new popup
            ActivityCompat.requestPermissions(here, new String[]{Manifest.permission.READ_PHONE_STATE, Manifest.permission.SEND_SMS}, 2);

        }
    }

    private void underGoal(Double newWeight){
        if(newWeight != null && weightdb.getGoalWeight() != null && newWeight <= weightdb.getGoalWeight()){
            //TODO
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) ==
                    PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                            this, Manifest.permission.READ_PHONE_STATE) ==
                             PackageManager.PERMISSION_GRANTED) {
                SmsManager smsManager = SmsManager.getDefault();
                TelephonyManager telephonyManager = (TelephonyManager) this.getSystemService(this.TELEPHONY_SERVICE);
                String phoneNum = telephonyManager.getLine1Number();
                if (phoneNum != null) {
                    smsManager.sendTextMessage(phoneNum, null,
                            "Congrats you reached your goal!", null, null);
                }
            }
            else {
                Snackbar.make(mainLayout, getString(R.string.goal_reached), Snackbar.LENGTH_LONG).show();
            }
        }

    }



}