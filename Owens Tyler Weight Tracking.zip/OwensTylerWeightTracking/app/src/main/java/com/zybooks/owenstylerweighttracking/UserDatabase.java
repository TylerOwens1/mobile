package com.zybooks.owenstylerweighttracking;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class UserDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightUsers.db";
    private static final int VERSION = 1;


    private static final class WeightUserTable {
        private static final String TABLE = "WeightUser";
        private static final String COL_ID = "_id";
        private static final String COL_USER = "Username";
        private static final String COL_PASS = "Password";
    }


    // create table sql query
    private String CREATE_USER_TABLE = "CREATE TABLE " + WeightUserTable.TABLE + "("
            + WeightUserTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + WeightUserTable.COL_USER + " TEXT,"
            + WeightUserTable.COL_PASS + " TEXT" + ")";

    // drop table sql query
    private String DROP_USER_TABLE = "DROP TABLE IF EXISTS " + WeightUserTable.TABLE;



    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL(DROP_USER_TABLE);
        db.execSQL(CREATE_USER_TABLE);
    }

    //Adds user to the database
    public void addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightUserTable.COL_USER, user.getName());
        values.put(WeightUserTable.COL_PASS, user.getPassword());

        db.insert(WeightUserTable.TABLE, null, values);
        db.close();
    }

    //chekds if a use is in the database true if they are false if they are not
    public boolean userExists(String userName, String pass) {

        String[] cols = {WeightUserTable.COL_ID};

        SQLiteDatabase db = this.getReadableDatabase();

        String selection = WeightUserTable.COL_USER + " = ?" + " AND " + WeightUserTable.COL_PASS + " = ?";

        String[] args = {userName, pass};

        Cursor cursor = db.query(WeightUserTable.TABLE,
                cols,
                selection,
                args,
                null,
                null,
                null);

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if(cursorCount > 0){
            return true;
        }
        else{
            return false;
        }
    }
}
