package com.zybooks.owenstylerweighttracking;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import com.google.android.material.snackbar.Snackbar;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private final AppCompatActivity activity = LoginActivity.this;

    private ConstraintLayout loginLayout;

    private EditText userNameText, passwordText;
    private Button logInButton, createAccountButton;
    private UserDatabase userDatabase;

    private Activity here;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_page);

        loginLayout = (ConstraintLayout) findViewById(R.id.loginLayout);

        userNameText = (EditText) findViewById(R.id.editUserName);
        passwordText = (EditText) findViewById(R.id.editTextTextPassword);



        logInButton = (Button) findViewById(R.id.buttonLogin);
        createAccountButton = (Button) findViewById(R.id.buttonCreateAccount);

        logInButton.setOnClickListener(this);
        createAccountButton.setOnClickListener(this);

        userDatabase = new UserDatabase(activity);
        here = this;

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.buttonLogin:
                verifyUser();
                break;
            case R.id.buttonCreateAccount:
                createUser();
                break;
        }

    }

    private void verifyUser() {
        //TODO
        if(userNameText.getText().toString().trim().isEmpty()
        || passwordText.getText().toString().trim().isEmpty()) {
            //TODO message for empytext
            Snackbar.make(loginLayout, getString(R.string.empty_user), Snackbar.LENGTH_LONG).show();

            return;
        }
        else if (userDatabase.userExists(userNameText.getText().toString().trim(), passwordText.getText().toString().trim())) {
            //TODO pull up next screen with this user working rn
            Intent myIntent = new Intent(this, MainActivity.class);
            startActivity(myIntent);
            return;
        }
        else {
            Snackbar.make(loginLayout, getString(R.string.invalid_user), Snackbar.LENGTH_LONG).show();
        }


    }

    private void createUser(){
        User user = new User();
        user.setName(this.userNameText.getText().toString().trim());
        user.setPassword(this.passwordText.getText().toString().trim());
        userDatabase.addUser(user);
        Snackbar.make(loginLayout, getString(R.string.added_user), Snackbar.LENGTH_LONG).show();
    }


}