package com.zybooks.owenstylerweighttracking;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class WeightRecordDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightRecord.db"; // use username in database?
    private static final int VERSION = 1;

    private Double goalWeight;

    public void clean() {

        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL(DROP_USER_TABLE);
        db.execSQL(CREATE_USER_TABLE);
    }

    private static final class WeightTable {
        private static final String TABLE = "Weight";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "Date";
        private static final String COL_WEIGHT = "Weight";
    }

    private String CREATE_USER_TABLE = "CREATE TABLE " + WeightRecordDatabase.WeightTable.TABLE + "("
            + WeightRecordDatabase.WeightTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + WeightTable.COL_DATE + " TEXT,"
            + WeightTable.COL_WEIGHT + " TEXT" + ")";


    // drop table sql query
    private String DROP_USER_TABLE = "DROP TABLE IF EXISTS " + WeightRecordDatabase.WeightTable.TABLE;



    public WeightRecordDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }




    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_USER_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL(DROP_USER_TABLE);
        db.execSQL(CREATE_USER_TABLE);

    }

    //Adds user to the database
    //True if the weight is higher than the user's goal weight
    public boolean addWeight(WeightRecord weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean beatGoal = false;
        //Double weightDouble = weight.getWeight().toString().trim();

        ContentValues values = new ContentValues();
        values.put(WeightRecordDatabase.WeightTable.COL_DATE, weight.getDate());
        values.put(WeightRecordDatabase.WeightTable.COL_WEIGHT, weight.getWeight());

        db.insert(WeightRecordDatabase.WeightTable.TABLE, null, values);
        db.close();
        return beatGoal;

    }

    public Double getGoalWeight() {
        return this.goalWeight;
    }

    public void setGoalWeight(Double goalWeight) {
        this.goalWeight = goalWeight;
    }

    public void removeWeight(WeightRecord record)  {

        SQLiteDatabase db = this.getWritableDatabase();
        // delete user record by id
        db.delete(WeightTable.TABLE, WeightTable.COL_ID + " = ?",
                new String[]{String.valueOf(record.getId())});
        db.close();
    }

    public void updateWeight(WeightRecord record) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_DATE, record.getDate());
        values.put(WeightTable.COL_WEIGHT, record.getWeight());
        // updating row
        db.update(WeightTable.TABLE, values, WeightTable.COL_ID + " = ?",
                new String[]{String.valueOf(record.getId())});
        db.close();
    }

    @SuppressLint("Range")
    public List<WeightRecord> getAllWeights() {

        // array of columns to fetch
        String[] columns = {
                WeightTable.COL_ID,
                WeightTable.COL_DATE,
                WeightTable.COL_WEIGHT,
        };

        SQLiteDatabase db = this.getReadableDatabase();
        // query the table
        Cursor cursor = db.query(WeightTable.TABLE,
                columns,    //columns to return
                null,
                null,
                null,
                null,
                null); //The sort order
        // Traversing through all rows and adding to list
        List<WeightRecord> weightList = new ArrayList<WeightRecord>();
        if (cursor.moveToFirst()) {
            do {
                WeightRecord record = new WeightRecord();
                record.setId(cursor.getInt(cursor.getColumnIndex(WeightTable.COL_ID)));
                record.setDate(cursor.getString(cursor.getColumnIndex(WeightTable.COL_DATE)));
                record.setWeight(cursor.getString(cursor.getColumnIndex(WeightTable.COL_WEIGHT)));
                // Adding user record to list
                weightList.add(record);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        return weightList;
    }
}
