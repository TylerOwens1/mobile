package com.zybooks.owenstylerweighttracking;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class userValidation {
    private Context context;

    public userValidation(Context c) {
        context = c;
    }

    // checks if an edittext is filled
    public boolean isFilled(TextInputEditText inputText, TextInputLayout textLayout, String errorMessage) {
        String text = inputText.getText().toString().trim();
        if(text.isEmpty()) {
            //TODO send error message
            textLayout.setError(errorMessage);
            hideKeyboardFrom(inputText);
            return false;
        } else {
            textLayout.setErrorEnabled(false);
        }

        return true;
    }


    private void hideKeyboardFrom(View view) {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }
}
